
Steps for Turtlubot Laptop(connected with turtlebot):

1) roscore

2) roslaunch turtlebot_bringup minimal.launch

please check the path of the map file before executing this command
3) roslaunch turtlebot_navigation amcl_demo.launch map_file:=~/catkin_ws/src/skeleton_markers-indigo-devel/mymap2.yaml


Steps for User's Laptop(connected with PrimeSense Sensor):

1) roslaunch turtlebot_rviz view_navigation.launch

2) roslaunch skeleton_markers skeleton.launch

3) cd ~/catkin_ws/src/skeleton_markers-indigo-devel

please check the path before executing this command
4) ./LeftRightNavigation.py


Stand in-front of the PrimeSense Camera and give a initial pose (lift your hands upwards making 90 degree angle between your elbo and hand) and wait for your skeleton being detected. (screen displays "Looking for pose")

once you see skeleton markers(lines between your skeleton joints) it means your skeleton is detected and you are ready to give direction to the robot (screen says "Tracking").

Then give the direction to the robot by lifting your left/right hand straight and pointing in any direction. Make sure to wait for 7-9 seconds before bringing the hand down so that the program have enough time to detect your hand direction.
(console will show the loading percentage 0-100)

once the console shows 100%, Robot will start moving in that direction.


Youtube Video link:
https://www.youtube.com/watch?v=NPNAYVbCwJQ
