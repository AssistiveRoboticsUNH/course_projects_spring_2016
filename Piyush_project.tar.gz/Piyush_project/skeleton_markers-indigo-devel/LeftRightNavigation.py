#!/usr/bin/env python
import rospy
import os
import actionlib
import amcl
from skeleton_markers.msg import Skeleton
from time import sleep
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from actionlib_msgs.msg import *
from geometry_msgs.msg import * #Pose, Point, Quaternion, amcl_pose
from nav_msgs.msg import Odometry

currentPosX=0.000
currentPosY=0.000
rQuat=0.207
lQuat=0.980
quat=0.000
steps=1.500

torso=0.000
leftHand=0.000
rightHand=0.000
leftDistance=0.000
rightDistance=0.000
srcX=0
srcY=0
dstX=0
dstY=0
xRight=-4.41
yRight=.611
position = {'x': -1.929, 'y' : .166}
i=0
per=" % "
sign=0

def callback(data):
    #rospy.loginfo(rospy.get_caller_id() + "Right Hand X: %s", data.name[7])
    torso=data.position[2].x
    leftHand=data.position[5].x
    rightHand=data.position[8].x
    leftDistance=torso-leftHand
    rightDistance=rightHand-torso
    #rospy.loginfo("\rPoints information: %s",)
    global i
    global quat
    if(leftDistance>rightDistance):
	global sign
	#rospy.loginfo("\r%s x: %s", data.name[4],data.position[4].x)
    	#rospy.loginfo("\r%s y: %s", data.name[4],data.position[4].y)
    	#rospy.loginfo("\r%s z: %s\n", data.name[4],data.position[4].z)
    	#rospy.loginfo("\r%s x: %s", data.name[5],data.position[5].x)
    	#rospy.loginfo("\r%s y: %s", data.name[5],data.position[5].y)
	#rospy.loginfo("\r%s\n", data.name[5])
	rospy.loginfo("\rdistance left: %s right: %s Analyzing direction: %s%s", leftDistance,rightDistance,i,per)
	#rospy.loginfo("\rQuat: %s",quat)
	quat=lQuat
	sign=-1
	
	
    else:
    	#rospy.loginfo("\r%s x: %s", data.name[7],data.position[7].x)
    	#rospy.loginfo("\r%s y: %s", data.name[7],data.position[7].y)
    	#rospy.loginfo("\r%s z: %s\n", data.name[7],data.position[7].z)
    	#rospy.loginfo("\r%s x: %s", data.name[8],data.position[8].x)
    	#rospy.loginfo("\r%s y: %s", data.name[8],data.position[8].y)
    	#rospy.loginfo("\r%s\n", data.name[8])
	rospy.loginfo("\rdistance left: %s right: %s Analyzing direction: %s%s", leftDistance,rightDistance,i,per)
	#rospy.loginfo("\rQuat: %s",quat)
	quat=rQuat
	sign=1
	
    if(leftDistance>.55 or rightDistance>.55):
	i+=1
	#rospy.loginfo("\ri: %s",i)
    else:
	i=0

    if(i==100):
	global srcX
	global srcY
	global dstX
	global dstY
	#os.system('clear')
	#rospy.loginfo("\rPosition Identified, Robot will start moving towards the goal now")
	srcX=currentPosX
	srcY=currentPosY
	dstX=currentPosX + (steps * sign)
	dstY=srcY
	position['x']=dstX
	position['y']=dstY
	move()
	i=0

    #os.system('clear')

def odometryCb(msg):
    global currentPosX
    global currentPosY
    currentPosX = msg.pose.pose.position.x
    currentPosY = msg.pose.pose.position.y

def moveto(msg):
    global currentPosX
    global currentPosY
    currentPosX = msg.pose.pose.position.x
    currentPosY = msg.pose.pose.position.y

def listener():

    # In ROS, nodes are uniquely named. If two nodes with the same
    # node are launched, the previous one is kicked off. The
    # anonymous=True flag means that rospy will choose a unique
    # name for our 'listener' node so that multiple listeners can
    # run simultaneously.
    rospy.init_node('listener', anonymous=True)
    #rospy.Subscriber('odom',Odometry,odometryCb)
    rospy.Subscriber("skeleton", Skeleton, callback)
    rospy.Subscriber("amcl_pose",PoseWithCovarianceStamped,moveto)

    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()

def move():
    try:
	global srcX
	global srcY
	global dstX
	global dstY
	global quat
        #rospy.init_node('nav_test', anonymous=True)
	goal_sent = False

	# Tell the action client that we want to spin a thread by default
	move_base = actionlib.SimpleActionClient("move_base", MoveBaseAction)
	#rospy.loginfo("Wait for the action server to come up")

	# What to do if shut down (e.g. Ctrl-C or failure)
	rospy.on_shutdown(move_base.cancel_goal)

	# Allow up to 5 seconds for the action server to come up
	move_base.wait_for_server(rospy.Duration(5))

        # Customize the following values so they are appropriate for your location
        #position = {'x': -1.929, 'y' : .166}
        quaternion = {'r1' : 0.000, 'r2' : 0.000, 'r3' : 0.000, 'r4' : 1.000}
        rospy.loginfo("\rGo to (%s, %s) from (%s, %s) pose", dstX,dstY,srcX,srcY)

	# Send a goal
        goal_sent = True
	goal = MoveBaseGoal()
	goal.target_pose.header.frame_id = 'map'
	goal.target_pose.header.stamp = rospy.Time.now()
        #goal.target_pose.pose = Pose(Point(position['x'], position['y'], 0.000),
        #                             Quaternion(quaternion['r1'], quaternion['r2'], quaternion['r3'], quaternion['r4']))
	goal.target_pose.pose = Pose(Point(position['x'], position['y'], 0.000),
                                     Quaternion(0.000, 0.000, 0.000, 1.000))

	# Start moving
        move_base.send_goal(goal)

	# Allow TurtleBot up to 60 seconds to complete task
	success = move_base.wait_for_result(rospy.Duration(60)) 

        state = move_base.get_state()
        success = False

        if success and state == GoalStatus.SUCCEEDED:
            # We made it!
            success = True
        else:
            move_base.cancel_goal()

        goal_sent = False

        if success:
            rospy.loginfo("Hooray, reached the desired pose")
        else:
            rospy.loginfo("The base failed to reach the desired pose")

        # Sleep to give the last log messages time to be sent
        rospy.sleep(1)

    except rospy.ROSInterruptException:
        rospy.loginfo("Ctrl-C caught. Quitting")


if __name__ == '__main__':
    listener()
