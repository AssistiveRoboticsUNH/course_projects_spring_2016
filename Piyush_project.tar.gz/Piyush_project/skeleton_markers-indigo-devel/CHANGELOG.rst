^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package skeleton_markers
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.4.1 (2013-12-30)
------------------
* Renamed skeleton_markers.py to markers_from_skeleton_msg.py since catkin cannot have a script with the same name as the package
* Removed roslib import from Python nodes
* Tweaked markers_from_tf.py to deal with user index suffix in frame names
* Initial commit
* Contributors: Patrick Goebel
